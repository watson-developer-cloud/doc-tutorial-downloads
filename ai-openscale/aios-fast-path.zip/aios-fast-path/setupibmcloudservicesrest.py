# ----------------------------------------------------------------------------------------------------
# IBM Confidential
# OCO Source Materials
# 5900-A3Q, 5737-J33
# Copyright IBM Corp. 2018
# The source code for this program is not published or other-wise divested of its trade
# secrets, irrespective of what has been deposited with the U.S.Copyright Office.
# ----------------------------------------------------------------------------------------------------
from resource_controller import *
from cloud_foundry import *
from setupibmcloudservices import *

class SetupIBMCloudServicesRest(SetupIBMCloudServices):

    def __init__(self, args, environment):
        super().__init__(args, environment)
        accessToken = TokenManager(apikey=args.apiKey, url=environment['iam_url']).get_token()
        self.resourceController = ResourceController(access_token=accessToken)
        accessToken = TokenManager(apikey=args.apiKey, url=environment['uaa_url'], iam_token=False).get_token()
        self.cloudFoundry = CloudFoundry(access_token=accessToken)

    def _getCredentials(self, params, isRCBased, credentialsFile=None):
        '''
        Returns the credentials from the specified credentials json file. If not
        then returns the credentials an instance of the specified Service.
        If there is no instance available, a new one is provisioned.
        If there are no existing credentials, new one is created and returned.
        '''
        print('\nSetting up {} instance'.format(params['service_display_name']))
        credentials = None

        if credentialsFile is not None and credentialsFile.strip():
            print('\t - Credentials file specified')
            print('\t - Reading from the file "{}" ...'.format(credentialsFile))
            credentials = jsonFileToDict(credentialsFile.strip())
            print('\t - Using credentials from "{}"'.format(credentialsFile))
        else:
            if isRCBased:
                credentials = self.resourceController.get_or_create_instance(
                                resource_id=params['resource_id'],
                                resource_name=params['instance_name'],
                                resource_plan_id=params['resource_plan_id'],
                                resource_group_name=self.args.resourceGroup,
                                create_credentials=params['create_credentials']
                            )
            else:
                credentials = self.cloudFoundry.get_or_create_instance(
                                service_name=params['service_name'],
                                service_instance_name=params['instance_name'],
                                service_plan_guid=params['service_plan_guid'],
                                organization_name=self.args.org,
                                space_name=self.args.space
                            )
        return credentials

    def setupAIOS(self):
        aiopenscale_params = {}
        aiopenscale_params['service_display_name'] = 'AI OpenScale'
        aiopenscale_params['instance_name'] = 'aiopenscale-fastpath-instance'
        aiopenscale_params['resource_id'] = RESOURCE_ID_AIOPENSCALE
        aiopenscale_params['resource_plan_id'] = PLAN_ID_AIOPENSCALE
        aiopenscale_params['create_credentials'] = False
        aios_instance = self._getCredentials(aiopenscale_params, True)
        aios_credentials = {}
        if self.args.env[:3].lower() == 'icp':
            aios_credentials['data_mart_id'] = uuid.uuid4()
            aios_credentials['url'] = self.environment['aios_url']
        else:
            aios_credentials['data_mart_id'] = aios_instance['id']
            aios_credentials['apikey'] = self.args.apiKey
            aios_credentials['url'] = self.environment['aios_url']
        return aios_credentials

    def setupWML(self):
        wml_params = {}
        wml_params['service_display_name'] = 'Watson Machine Learning'
        wml_params['instance_name'] = 'wml-fastpath-instance'
        wml_params['resource_id'] = RESOURCE_ID_MACHINE_LEARNING
        wml_params['resource_plan_id'] = PLAN_ID_MACHINE_LEARNING
        wml_params['create_credentials'] = True
        if self.args.wmlVCAP is not None:
            return self._getCredentials(wml_params, True, self.args.wmlVCAP)
        return self._getCredentials(wml_params, True)['credentials']

    def setupPostgresDatabase(self):
        postgres_params = {}
        postgres_params['service_display_name'] = 'Compose for PostgreSQL'
        if self.args.postgresVCAP is not None:
            return self._getCredentials(postgres_params, False, self.args.postgresVCAP)
        print('\nUsing AIOS internal database')
        return None
