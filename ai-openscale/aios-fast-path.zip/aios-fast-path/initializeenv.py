# ----------------------------------------------------------------------------------------------------
# IBM Confidential
# OCO Source Materials
# 5900-A3Q, 5737-J33
# Copyright IBM Corp. 2018
# The source code for this program is not published or other-wise divested of its trade
# secrets, irrespective of what has been deposited with the U.S.Copyright Office.
# ----------------------------------------------------------------------------------------------------
from utils import *

def initialize(args, env):
    if args.bx:
        print('\nInitializing IBM Cloud environment')
        print('\t - Using IBM CLoud CLI to setup IBM Cloud services')
        print('\t - Using apikey to log-in with resource-group "{}" ...'.format(args.resourceGroup))
        executeCommand('bx login --apikey "{}" -a "{}"'.format(args.apiKey, env['api']))
        executeCommand('bx target -g "{}"'.format(args.resourceGroup))
    else:
        print('\nInitializing')
        print('\t - Using REST API to setup IBM Cloud services')
    print('\t - Initialization done')

