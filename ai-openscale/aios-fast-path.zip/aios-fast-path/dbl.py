# ----------------------------------------------------------------------------------------------------
# IBM Confidential
# OCO Source Materials
# 5900-A3Q, 5737-J33
# Copyright IBM Corp. 2018
# The source code for this program is not published or other-wise divested of its trade 
# secrets, irrespective of what has been deposited with the U.S.Copyright Office.
# ----------------------------------------------------------------------------------------------------
from setupAIOS import AIOSTool
from watson_machine_learning_client import WatsonMachineLearningAPIClient
import json




if __name__ == '__main__':
    myModelName='m2'
    with open('wmlCredentials.json') as f:
        wml_credentials = json.load(f) 

    client = WatsonMachineLearningAPIClient(wml_credentials)

    print("getting instance details")
    instanceDetails = client.service_instance.get_details()
    print(instanceDetails)
    
    client.repository.list_definitions()
    
    with open('metaData.json') as f:
        metaData = json.load(f)

    
    client.repository.list_models()
    # client.repository.download('be9a549b-bf24-47bf-b1ef-fc7b5aa41e60', 'mymodel.tgz')
    
    print("Checking for models named: {}".format(myModelName))
    models = client.repository.get_model_details()
    for model in models['resources']:
        thisModelName = model['entity']['name']
        if myModelName == thisModelName:
            print("deleting model: {}".format(thisModelName))
            client.repository.delete(model['metadata']['guid'])

    print("Creating new model")
    client.repository.store_model('mymodel.tar.gz', metaData)
    
    print("Getting definition details")
    definitions = client.repository.get_definition_details()
    print(json.JSONEncoder().encode(definitions))
    
    for definition in definitions['resources']:
        print(json.JSONEncoder().encode(definition))
        
        print("getting definition uids")
        uid = client.repository.get_definition_uid(definition)
        print(uid) 
    
    print("Getting details (all details)")
    details = client.repository.get_details()
    print(json.JSONEncoder().encode(details))
    
    print("getting model details")
    models = client.repository.get_model_details()
    print(json.JSONEncoder().encode(models))    
    
    for model in models['resources']:
        print("Guid: {}, Name: {}".format(model['metadata']['guid'], model['entity']['name']))
        print(json.JSONEncoder().encode(model))
    
    tool = AIOSTool()
    tool.setupWMLModels()

    client.repository.list_models()
