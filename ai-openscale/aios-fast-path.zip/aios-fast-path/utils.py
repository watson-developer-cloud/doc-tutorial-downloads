# ----------------------------------------------------------------------------------------------------
# IBM Confidential
# OCO Source Materials
# 5900-A3Q, 5737-J33
# Copyright IBM Corp. 2018
# The source code for this program is not published or other-wise divested of its trade 
# secrets, irrespective of what has been deposited with the U.S.Copyright Office.
# ----------------------------------------------------------------------------------------------------
import json
import subprocess
import requests

def executeCommandWithResult(cmd):
    '''
    Run command and capture the output of the command
    '''
    status, result = subprocess.getstatusoutput(cmd)
    if status != 0:
        # print("\t( warning: Non 0 exit status! Reason: {}) ".format(result.rstrip()))
        return None
    return result

def executeCommand(cmd):
    '''
    Run command
    '''
    status, result = subprocess.getstatusoutput(cmd)
    if status != 0:
        print("ERROR: Exited with {} status while trying to execute {}. Reason: {}".format(status, cmd, result))
        exit(1)
    # print(result)

def jsonFileToDict(filename):
    '''
    reads the json file specfied and returns it as a dictionary
    '''
    result = None
    if (filename is not None and filename.strip()):
        with open(filename.strip()) as f:
            result = json.load(f)
    if result is None:
        print("ERROR: Unable to read file '{}'".format(filename))
        exit(1)
    return result

def getExplainabilityBody(modelMetaData, datamartName, serviceBinding, modelId, catagoricalColumns, aiosCredentials):
    result = {
        "data_mart_id": aiosCredentials['data_mart_id'],
        "service_binding_id": serviceBinding,
        "model_id": modelId,
        "parameters": {
            "model_type": modelMetaData['evaluation']['method'],
            "model_data_type": "numeric_categorical",
            "model_source": "wml",
            "label_column": modelMetaData['label_column'],
            "feature_columns": [d.get('name') for d in modelMetaData['training_data_schema']['fields'] if d.get('name') != modelMetaData['label_column']],
            "catagorical_columns": catagoricalColumns,
            "training_data_reference": modelMetaData['training_data_reference'][0]
        }
    }
    return result

def getIamHeaders(aiosCredentials, iam_url):
    # get a bearer token for storing historical measurementfacts
    token_data = {'grant_type': 'urn:ibm:params:oauth:grant-type:apikey', 'response_type': 'cloud_iam', 'apikey': aiosCredentials["apikey"]}
    response_token = requests.post(iam_url, data=token_data)
    iam_token = response_token.json()["access_token"]
    iam_headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer ' + iam_token}
    return iam_headers
