### Setup Steps and running the fast setup tool

You will be using the MacOS/Linux/Windows command line to perform these steps. All but the last step are one-time only.

1. Install Python 3.x via anaconda
    - anaconda - https://www.anaconda.com/download (choose the python 3 version)
2. Install needed modules:
    - ibm-ai-openscale version 1.0.89 or higher
    - watson-machine-learning-client version 1.0.339 or higher

    Temporary until ibm-ai-openscale 1.0.89+ is in production, run the following command:
    ```
    pip install -I --user --index https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple ibm-ai-openscale
    ```
    Temporary until watson-machine-learning-client 1.0.339+ is in production, run the following command:
    ```
    pip install -I --user --index https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple watson-machine-learning-client
    ```
3. Get (and save) an IBM Cloud API Key.
	- https://console.bluemix.net/docs/iam/userid_keys.html#userapikey
4. If you already have a Watson Machine Learning (WML) instance, ensure it's RC-enabled. This can be done going to the IBM Cloud Dashboard: https://console.bluemix.net/dashboard/apps and making sure that the instance shows up under "Services".
    - If you know you have one, and it's NOT in the list, then it needs migrating - see: https://console.bluemix.net/docs/resources/instance_migration.html#migrate.
5. If you have a non-english locale set in your terminal (MacOS/Linux), use the following command to switch it to english:
    ```
    export LANG=en_US.UTF-8
    ```
6. From the directory you have setupAIOS.py in, run the script:
    ```
    python setupAIOS.py --apiKey <your api key from step 3>
    ```
    For example (using the results from step 6):
    ```
    python setupAIOS.py --apiKey q3ps8shesjdh8as8s9s6k47DfIEW-T2ba8jsksy4wkW3
    ```
