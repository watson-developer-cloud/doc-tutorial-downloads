# ----------------------------------------------------------------------------------------------------
# IBM Confidential
# OCO Source Materials
# 5900-A3Q, 5737-J33
# Copyright IBM Corp. 2018
# The source code for this program is not published or other-wise divested of its trade
# secrets, irrespective of what has been deposited with the U.S.Copyright Office.
# ----------------------------------------------------------------------------------------------------
'''
Created on Oct 30, 2018

@author: YongLi
'''
import argparse
import os
import psycopg2
import random # for generating scoring requests
import requests # for storing historical MeasurementFacts
import subprocess
import sys
import datetime
from environments import *
from initializeenv import *
from setupibmcloudservicesbx import *
from setupibmcloudservicesrest import *
from ibm_ai_openscale import APIClient
from ibm_ai_openscale.engines import *
from ibm_ai_openscale.supporting_classes import *
from watson_machine_learning_client import WatsonMachineLearningAPIClient

pythonFileDir = os.path.dirname(__file__)

### Helper functions
class AIOSTool:

    def __init__(self):
        return

    # Rohit
    def processArgs(self):
        print('')
        parser=argparse.ArgumentParser()
        optionalArgs = parser._action_groups.pop()
        requiredArgs = parser.add_argument_group('required arguments')
        requiredArgs.add_argument('-a', '--apiKey', help='IBM Cloud APIKey', required=True)
        # requiredArgs.add_argument('--org', help='Cloud Foundry Org to use', required=True)
        # requiredArgs.add_argument('--space', help='Cloud Foundry Space to use', required=True)
        parser.add_argument('--resourceGroup', default='default', help='Resource Group to use. If not specified, then "default" group is used')
        parser.add_argument('--postgresVCAP', help='Path to postgres properties file. If not specified, then the internal AIOS database is used')
        parser.add_argument('--wmlVCAP', help='Path to WML properties file')
        parser.add_argument('--datamartName', default='aiosfastpath', help='Specify data mart name, default is "aiosfastpath"')
        parser.add_argument('--env', default='ypprod', help='Environment to use: ypprod, ypqa, ys1dev or icp:https://0.0.0.0:0000. Default is "ypprod"')
        parser.add_argument('--history', default=7, help='Days of history to preload. Default is 7')
        parser.add_argument('--bx', action='store_true', help='Specify (without a value) to use IBM Cloud CLI (bx CLI), default uses Rest API.')
        parser._action_groups.append(optionalArgs)
        args = parser.parse_args()
        # validate environment
        if args.env not in ['ypprod', 'ypqa', 'ys1dev']:
            if args.env[:3] != 'icp':
                print('ERROR: Invalid environment specified. Please run the tool with "--help" to see the correct usage.')
                exit(1)
        return args

    # Don
    def setupWMLModels(self, credentials, env):
        '''
        Discover a list of models in the models sub directory. For each model, create the model in WML,
        Train this model, deploy this model, then configure accuracy monitoring in this model
        '''
        client = WatsonMachineLearningAPIClient(credentials)

        modelInfo = env['heart_drug_model_info']
        myModelName = modelInfo['model_name']
        myDeploymentName = modelInfo['deployment_name']
        myFolderName = modelInfo['folder_name']
        myDeploymentDescription = 'Created by aios fast path.'
        myModelFile = os.path.join(pythonFileDir, 'models', myFolderName, 'model-content.gzip')
        myModelMetaData = os.path.join(pythonFileDir, 'models', myFolderName, 'model-meta.txt')
        myPipelineMetaFile = os.path.join(pythonFileDir, 'models', myFolderName, 'pipeline-meta.json')
        myPipelineFile = os.path.join(pythonFileDir, 'models', myFolderName, 'pipeline-content.tgz')

        client.repository.list_models()
        # client.repository.download('be9a549b-bf24-47bf-b1ef-fc7b5aa41e60', 'mymodel.tgz')

        print("Checking for models named: {}".format(myModelName))
        models = client.repository.get_model_details()

        for model in models['resources']:
            thisModelName = model['entity']['name']
            if myModelName == thisModelName:
                print("deleting model: {}".format(thisModelName))
                client.repository.delete(model['metadata']['guid'])

        print("Creating pipeline for model: {}".format(myModelName))
        pipelineMetaData = jsonFileToDict(myPipelineMetaFile)
        pipeline_props = {
            client.repository.DefinitionMetaNames.AUTHOR_NAME: pipelineMetaData['author']['name'],
            client.repository.DefinitionMetaNames.NAME: pipelineMetaData['name'],
            client.repository.DefinitionMetaNames.FRAMEWORK_NAME: pipelineMetaData['framework']['name'],
            client.repository.DefinitionMetaNames.FRAMEWORK_VERSION: pipelineMetaData['framework']['version'],
            client.repository.DefinitionMetaNames.RUNTIME_NAME: pipelineMetaData['framework']['runtimes'][0]['name'],
            client.repository.DefinitionMetaNames.RUNTIME_VERSION: pipelineMetaData['framework']['runtimes'][0]['version'],
            client.repository.DefinitionMetaNames.DESCRIPTION: pipelineMetaData['description'],
            client.repository.DefinitionMetaNames.TRAINING_DATA_REFERENCES: pipelineMetaData['training_data_reference']
        }

        definition_details = client.repository.store_definition(myPipelineFile, meta_props=pipeline_props)

        with open(myModelMetaData) as f:
            metaData = json.load(f)

        model_props = {
            # use myModelName instead of metaData['name'] since we are using different model names for different envs
            client.repository.ModelMetaNames.NAME: myModelName,
            client.repository.ModelMetaNames.FRAMEWORK_NAME: metaData['framework']['name'],
            client.repository.ModelMetaNames.FRAMEWORK_VERSION: metaData['framework']['version'],
            client.repository.ModelMetaNames.RUNTIME_NAME: metaData['framework']['runtimes'][0]['name'],
            client.repository.ModelMetaNames.RUNTIME_VERSION: metaData['framework']['runtimes'][0]['version'],
            client.repository.ModelMetaNames.TRAINING_DATA_REFERENCE: metaData['training_data_reference'][0],

            #client.repository.ModelMetaNames.TRAINING_DATA_SCHEMA: metaData['training_data_schema'],
            client.repository.ModelMetaNames.TRAINING_DATA_SCHEMA: {'type': 'struct', 'fields': [{'name': 'AGE', 'nullable': True, 'metadata': {}, 'type': 'double'}, {'name': 'SEX', 'nullable': True, 'metadata': {}, 'type': 'string'}, {'name': 'BP', 'nullable': True, 'metadata': {}, 'type': 'string'}, {'name': 'CHOLESTEROL', 'nullable': True, 'metadata': {}, 'type': 'string'}, {'name': 'NA', 'nullable': True, 'metadata': {}, 'type': 'double'}, {'name': 'K', 'nullable': True, 'metadata': {}, 'type': 'double'}, {'name': 'DRUG', 'nullable': True, 'metadata': {'values': ['drugX', 'drugB', 'drugA', 'drugC'], 'modeling_role': 'target'}, 'type': 'string'}]},
            #client.repository.ModelMetaNames.OUTPUT_DATA_SCHEMA: metaData['output_data_schema'],
            client.repository.ModelMetaNames.OUTPUT_DATA_SCHEMA: {'type': 'struct', 'fields': [{'name': 'AGE', 'nullable': True, 'metadata': {}, 'type': 'double'}, {'name': 'SEX', 'nullable': True, 'metadata': {}, 'type': 'string'}, {'name': 'BP', 'nullable': True, 'metadata': {}, 'type': 'string'}, {'name': 'CHOLESTEROL', 'nullable': True, 'metadata': {}, 'type': 'string'}, {'name': 'NA', 'nullable': True, 'metadata': {}, 'type': 'double'}, {'name': 'K', 'nullable': True, 'metadata': {}, 'type': 'double'}, {'name': 'prediction', 'nullable': True, 'metadata': {'modeling_role': 'prediction'}, 'type': 'double'}, {'name': 'predictedLabel', 'nullable': True, 'metadata': {'values': ['drugX', 'drugB', 'drugA', 'drugC'], 'modeling_role': 'decoded-target'}, 'type': 'string'}, {'name': 'probability', 'nullable': True, 'metadata': {'modeling_role': 'probability'}, 'type': {'type': 'array', 'containsNull': True, 'elementType': 'double'}}]},

            client.repository.ModelMetaNames.EVALUATION_METHOD: metaData['evaluation']['method'],
            client.repository.ModelMetaNames.EVALUATION_METRICS: metaData['evaluation']['metrics'],

            #client.repository.ModelMetaNames.INPUT_DATA_SCHEMA: {'fields': [d for d in metaData['training_data_schema']['fields'] if d.get('name') != metaData['label_column']]}
            client.repository.ModelMetaNames.INPUT_DATA_SCHEMA: {'type': 'struct', 'fields': [{'name': 'AGE', 'nullable': True, 'metadata': {}, 'type': 'double'}, {'name': 'SEX', 'nullable': True, 'metadata': {}, 'type': 'string'}, {'name': 'BP', 'nullable': True, 'metadata': {}, 'type': 'string'}, {'name': 'CHOLESTEROL', 'nullable': True, 'metadata': {}, 'type': 'string'}, {'name': 'NA', 'nullable': True, 'metadata': {}, 'type': 'double'}, {'name': 'K', 'nullable': True, 'metadata': {}, 'type': 'double'}]}
        }

        print("Creating new model")
        details = client.repository.store_model(myModelFile, model_props)
        guid = client.repository.get_model_uid(details)

        client.repository.list_models()



        deploymentDetails = client.deployments.get_details()
        for details in deploymentDetails['resources']:
            depGuid = details['metadata']['guid']
            depName = details['entity']['name']
            print("Name: {}, GUID: {}".format(depName, depGuid))
            if depName == myDeploymentName:
                client.deployments.delete(depGuid)

        details = client.deployments.create(artifact_uid=guid, name=myDeploymentName, description=myDeploymentDescription)
        depGuid = details['metadata']['guid']
        depName = details['entity']['name']

        deploymentDetails = client.deployments.get_details()
        for details in deploymentDetails['resources']:
            print("Name: {}, GUID: {}".format(details['entity']['name'], details['metadata']['guid']))

        return (guid, myModelName, depGuid, depName, metaData)

    # DR
    def getAIOSPythonClient(self, aiosCredentials):
        '''
        Connect to AIOS Python client
        '''
        aiosClient = None
        for i in range(5):
            try:
                aiosClient = APIClient(aiosCredentials)
                break
            except Exception as e:
                print("Get AIOS Python client failed: {}".format(e))
                if 4-i > 0:
                    print("Retry in 1 minute, up to {} more time(s) . . .".format(4-i))
                    time.sleep(60)
                else:
                    raise e
        if aiosClient != None:
            print("\tUsing AIOS Python Client version: {}".format(aiosClient.version))
        return aiosClient

    # DR
    def createDatamart(self, datamartName, aiosClient, postgresCredentials):
        '''
        Create datamart schema and datamart
        '''
        if postgresCredentials != None:
            print("\tConnect to postgres: {}".format(datamartName))
            hostname = postgresCredentials['uri'].split('@')[1].split(':')[0]
            port = postgresCredentials['uri'].split('@')[1].split(':')[1].split('/')[0]
            user = postgresCredentials['uri'].split('@')[0].split('//')[1].split(':')[0]
            password = postgresCredentials['uri'].split('@')[0].split('//')[1].split(':')[1]
            dbname = postgresCredentials['uri'].split('@')[1].split('/')[1]
            conn_string = "host='{}' port='{}' dbname='{}' user='{}' password='{}'".format(hostname, port, dbname, user, password)

            for i in range(5):
                try:
                    conn = psycopg2.connect(conn_string)
                    break
                except Exception as e:
                    print("Postgres connection failed: {}".format(e))
                    if 4-i > 0:
                        print("Retry in 1 minute, up to {} more time(s) . . .".format(4-i))
                        time.sleep(60)
                    else:
                        raise e

        print("\tClean up datamart, if already present: {}".format(datamartName))
        for i in range(5):
            try:
                bindings_uids = aiosClient.data_mart.bindings.get_uids()
                subscriptions_uids = aiosClient.data_mart.subscriptions.get_uids()

                # clean up all subscriptions in the datamart
                for subscription_uid in subscriptions_uids:
                    # disable explainability, fairness checking, and payload logging for the subscription
                    subscription = aiosClient.data_mart.subscriptions.get(subscription_uid)
                    subscription._explainability.disable()
                    subscription.fairness_monitoring.disable()
                    subscription.payload_logging.disable()
                    # then remove the subscription itself
                    aiosClient.data_mart.subscriptions.delete(subscription_uid)

                # remove bindings
                for binding_uid in bindings_uids:
                    aiosClient.data_mart.bindings.delete(binding_uid)
                break
            except Exception as e:
                print("Datamart cleanup failed: {}".format(e))
                if 4-i > 0:
                    print("Retry in 1 minute, up to {} more time(s) . . .".format(4-i))
                    time.sleep(60)
                else:
                    raise e

        # remove previous datamart
        try:
            aiosClient.data_mart.delete()
        except:
            pass # assume datamart doesn't exist, no need to delete

        print("\tCreate datamart: {}".format(datamartName))
        for i in range(5):
            try:
                if postgresCredentials == None:
                    aiosClient.data_mart.setup(internal_db=True)
                else:
                    # remove previous schema
                    with conn: # transaction
                        with conn.cursor() as cursor:
                            dropschema = "DROP SCHEMA IF EXISTS {} CASCADE".format(datamartName)
                            cursor.execute(dropschema)
                            createschema = "CREATE SCHEMA {}".format(datamartName)
                            cursor.execute(createschema)
                    aiosClient.data_mart.setup(db_credentials=postgresCredentials, schema=datamartName)
                break
            except Exception as e:
                print("Datamart create failed: {}".format(e))
                if 4-i > 0:
                    print("Retry in 1 minute, up to {} more time(s) . . .".format(4-i))
                    time.sleep(60)
                else:
                    raise e

    # DR
    def bindWMLToAIOS(self, aiosClient, wmlCredentials):
        '''
        Bind WML instance to AIOS
        '''
        print("\tBind WML Instance to AIOS")
        binding_uid = None
        for i in range(5):
            try:
                binding_uid = aiosClient.data_mart.bindings.add("WML instance", WatsonMachineLearningInstance(wmlCredentials))
                break
            except Exception as e:
                print("WML binding failed: {}".format(e))
                if 4-i > 0:
                    print("Retry in 1 minute, up to {} more time(s) . . .".format(4-i))
                    time.sleep(60)
                else:
                    raise e
        return binding_uid


    # DR
    def registerModelToAIOS(self, modelName, modelGuid, bindingGuid, aiosClient, modelMetaData, datamartName, aiosCredentials, env):
        '''
        Create subscription in AIOS for drug-selection model
        Configure payload logging plus performance, fairness, explainability, and accuracy monitoring
        '''
        print("\tRegister WML Model to AIOS: {}".format(modelName))
        for i in range(5):
            try:
                 subscription = aiosClient.data_mart.subscriptions.add(WatsonMachineLearningAsset(modelGuid))
                 break
            except Exception as e:
                print("Register model to AIOS failed: {}".format(e))
                if 4-i > 0:
                    print("Retry in 1 minute, up to {} more time(s) . . .".format(4-i))
                    time.sleep(60)
                else:
                    raise e

        for i in range(5):
            try:
                print("\tEnable payload logging in AIOS: {}".format(modelName))
                subscription.payload_logging.enable()

                print("\tEnable Performance Monitoring in AIOS: {}".format(modelName))
                subscription.performance_monitoring.enable()

                print("\tConfiguring fairness monitoring for model: {}".format(modelName))
                if modelName == env['heart_drug_model_info']['model_name']:
                    subscription.fairness_monitoring.enable(
                            features=[
                            Feature("AGE", majority=[[49,59],[60,75]], minority=[[0,48],[76,99]], threshold=0.8),
                            Feature("SEX", majority=["M"], minority=["F"], threshold=0.8)
                        ],
                        prediction_column="prediction",
                        favourable_classes=[0,4],
                        unfavourable_classes=[1,2,3],
                        min_records=40
                    )
                else:
                    print("\t--- Fairness configuration not yet supported for model: {}".format(modelName))

                print("\tConfiguring accuracy monitoring for model: {}".format(modelName))
                if modelName == env['heart_drug_model_info']['model_name']:
                    subscription.quality_monitoring.enable(evaluation_method='multiclass', threshold=0.8, min_records=40)
                    feedbackValues = [
                            [58.0, 'F', 'HIGH', 'NORMAL', 0.868924, 0.061023, 'drugB'],
                            [68.0, 'F', 'HIGH', 'NORMAL', 0.77541, 0.0761, 'drugB'],
                            [65.0, 'M', 'HIGH', 'NORMAL', 0.635551, 0.056043, 'drugB'],
                            [60.0, 'F', 'HIGH', 'HIGH', 0.800607, 0.060181, 'drugB'],
                            [70.0, 'M', 'HIGH', 'HIGH', 0.658606, 0.047153, 'drugB'],
                            [60.0, 'M', 'HIGH', 'HIGH', 0.805651, 0.057821, 'drugB'],
                            [59.0, 'M', 'HIGH', 'HIGH', 0.816356, 0.058583, 'drugB'],
                            [72.0, 'M', 'HIGH', 'NORMAL', 0.72142, 0.074552, 'drugB'],
                            [53.0, 'F', 'HIGH', 'NORMAL', 0.760809, 0.060889, 'drugB'],
                            [55.0, 'F', 'HIGH', 'HIGH', 0.637231, 0.058054, 'drugB'],
                            [51.0, 'M', 'HIGH', 'NORMAL', 0.832467, 0.073392, 'drugB'],
                            [49.0, 'M', 'HIGH', 'NORMAL', 0.500169, 0.079788, 'drugA'],
                            [39.0, 'M', 'HIGH', 'HIGH', 0.731091, 0.075652, 'drugA'],
                            [26.0, 'F', 'HIGH', 'NORMAL', 0.781928, 0.063535, 'drugA'],
                            [49.0, 'M', 'HIGH', 'NORMAL', 0.538183, 0.061859, 'drugA'],
                            [31.0, 'M', 'HIGH', 'NORMAL', 0.749717, 0.06678, 'drugA'],
                            [20.0, 'F', 'HIGH', 'HIGH', 0.887426, 0.078798, 'drugA'],
                            [42.0, 'M', 'HIGH', 'NORMAL', 0.85794, 0.067203, 'drugA'],
                            [48.0, 'M', 'HIGH', 'NORMAL', 0.769197, 0.073633, 'drugA'],
                            [47.0, 'M', 'HIGH', 'HIGH', 0.56332, 0.054152, 'drugA'],
                            [23.0, 'M', 'HIGH', 'HIGH', 0.53406, 0.066666, 'drugA'],
                            [68.0, 'M', 'LOW', 'HIGH', 0.726677, 0.070616, 'drugC'],
                            [26.0, 'F', 'LOW', 'HIGH', 0.578002, 0.040819, 'drugC'],
                            [32.0, 'F', 'LOW', 'HIGH', 0.730854, 0.075256, 'drugC'],
                            [47.0, 'F', 'LOW', 'HIGH', 0.539774, 0.05362, 'drugC'],
                            [28.0, 'F', 'LOW', 'HIGH', 0.656292, 0.049997, 'drugC'],
                            [22.0, 'M', 'LOW', 'HIGH', 0.526672, 0.064617, 'drugC'],
                            [49.0, 'M', 'LOW', 'HIGH', 0.655222, 0.062181, 'drugC'],
                            [18.0, 'F', 'NORMAL', 'NORMAL', 0.553567, 0.063265, 'drugX'],
                            [49.0, 'M', 'LOW', 'NORMAL', 0.625889, 0.056828, 'drugX'],
                            [53.0, 'M', 'NORMAL', 'HIGH', 0.644936, 0.045632, 'drugX'],
                            [46.0, 'M', 'NORMAL', 'NORMAL', 0.526226, 0.072234, 'drugX'],
                            [39.0, 'M', 'LOW', 'NORMAL', 0.604973, 0.043404, 'drugX'],
                            [39.0, 'F', 'NORMAL', 'NORMAL', 0.517515, 0.053301, 'drugX'],
                            [15.0, 'M', 'NORMAL', 'HIGH', 0.64236, 0.07071, 'drugX'],
                            [23.0, 'M', 'NORMAL', 'HIGH', 0.593596, 0.048417, 'drugX'],
                            [50.0, 'F', 'NORMAL', 'NORMAL', 0.601915, 0.048957, 'drugX'],
                            [66.0, 'F', 'NORMAL', 'NORMAL', 0.611333, 0.075412, 'drugX'],
                            [67.0, 'M', 'NORMAL', 'NORMAL', 0.846892, 0.077711, 'drugX'],
                            [60.0, 'M', 'NORMAL', 'NORMAL', 0.645515, 0.063971, 'drugX'],
                            [45.0, 'M', 'LOW', 'NORMAL', 0.532632, 0.063636, 'drugX'],
                            [17.0, 'M', 'NORMAL', 'NORMAL', 0.722286, 0.06668, 'drugX'],
                            [24.0, 'F', 'NORMAL', 'HIGH', 0.80554, 0.07596, 'drugX']
                    ]
                    feedbackFields=['AGE', 'SEX', 'BP', 'CHOLESTEROL', 'NA', 'K', 'DRUG']
                    subscription.feedback_logging.store(feedbackValues, fields=feedbackFields)
                else:
                    print("\t--- Accuracy configuration not yet supported for model: {}".format(modelName))

                print("\tConfiguring explainability monitoring for model: {}".format(modelName))
                if modelName == env['heart_drug_model_info']['model_name']:
                    iamHeaders=getIamHeaders(aiosCredentials, env['iam_url'])
                    expBody = getExplainabilityBody(modelMetaData, datamartName, subscription.binding_uid, modelGuid, ['SEX', 'BP', 'CHOLESTEROL'], aiosCredentials)
                    reply = requests.post(aiosCredentials["url"] + '/v1/model_explanation_configurations', json=expBody, headers=iamHeaders)
                    reply.raise_for_status()
                else:
                    print("\tConfiguring explainability monitoring for model: {} (not yet supported)".format(modelName))

                print("\tLogging and monitoring configuration completed")
                break
            except Exception as e:
                print("Logging / monitoring configuration failed: {}".format(e))
                if 4-i > 0:
                    print("Retry in 1 minute, up to {} more time(s) . . .".format(4-i))
                    time.sleep(60)
                else:
                    raise e

        return subscription

    # DR
    def generateSampleScoring(self, datamartName, aiosCredentials, modelName, modelGuid, deployGuid, bindingGuid, subscription, aiosClient, env, historyDays):
        '''
        Generate historical data
        Generate sample scoring requests
        Trigger fairness check
        '''
        metricsurl = aiosCredentials["url"] + "/v1/data_marts/" + aiosCredentials["data_mart_id"] + "/metrics"
        iamHeaders=getIamHeaders(aiosCredentials, env['iam_url'])

        wmlClient = aiosClient.data_mart.bindings.get_native_engine_client(binding_uid=bindingGuid)
        deploymentDetails = wmlClient.deployments.get_details(deployGuid)
        deploymentUrl = wmlClient.deployments.get_scoring_url(deploymentDetails)

        print("\tLoad historical scoring records to Payload Logging and MeasurementFacts tables in AIOS: {}".format(modelName))

        if modelName == env['heart_drug_model_info']['model_name']:
            historyfile = os.path.join(pythonFileDir, 'models', env['heart_drug_model_info']['folder_name'], 'historypayloads.json')
        else:
            print("\t--- Loading scoring history not yet supported for model: {}".format(modelName))
            historyfile = None

        if historyfile != None:
            with open(historyfile) as f:
                payloads = json.load(f)
            for day in range(historyDays):
                print("\t--- loading day {}".format(day+1))
                for hour in range(24):
                    # store payload logging history in Payload table
                    recordsList = []
                    for payload in payloads:
                        score_time=str(datetime.datetime.utcnow() + datetime.timedelta(hours=(-(24*day + hour + 1))))
                        recordsList.append(PayloadRecord(request=payload["request"], response=payload["response"], scoring_timestamp=score_time))
                    start = time.time()
                    subscription.payload_logging.store(records=recordsList)

                    # store performance monitor history in MeasurementFacts table
                    score_time = (datetime.datetime.utcnow() + datetime.timedelta(hours=(-(24*day + hour + 1)))).strftime("%Y-%m-%dT%H:%M:%SZ")
                    score_count = random.randint(60,600)
                    score_resp = random.uniform(60,300)
                    performanceMetric = {
                        "metric_type": "performance",
                        "binding_id": bindingGuid,
                        "timestamp": score_time,
                        "subscription_id": modelGuid,
                        "asset_revision": modelGuid,
                        "deployment_id": deployGuid,
                        "value": { "response_time": score_resp, "records": score_count }
                    }
                    response = requests.post(metricsurl, json=[performanceMetric], headers=iamHeaders)

        print("\tLoad historical fairness MeasurementFacts to AIOS: {}".format(modelName))
        if modelName == env['heart_drug_model_info']['model_name']:
            historyfile = os.path.join(pythonFileDir, 'models', env['heart_drug_model_info']['folder_name'], 'historyfairness.json')
        else:
            print("\t--- Loading fairness history not yet supported for model: {}".format(modelName))
            historyfile = None

        if historyfile != None:
            with open(historyfile) as f:
                fairnessValues = json.load(f)
            for day in range(historyDays):
                print("\t--- loading day {}".format(day+1))
                for hour in range(24):
                    fairnessTime = (datetime.datetime.utcnow() + datetime.timedelta(hours=(-(24*day + hour + 1)))).strftime("%Y-%m-%dT%H:%M:%SZ")
                    fairnessMetric = {
                        "metric_type": "fairness",
                        "binding_id": bindingGuid,
                        "timestamp": fairnessTime,
                        "subscription_id": modelGuid,
                        "asset_revision": modelGuid,
                        "deployment_id": deployGuid,
                        "value": fairnessValues[random.randint(0, len(fairnessValues))-1]
                    }
                    response = requests.post(metricsurl, json=[fairnessMetric], headers=iamHeaders)
        else:
            print("\t--- Loading fairness history not yet supported for model: {}".format(modelName))

        print("\tLoad historical quality MeasurementFacts to AIOS: {}".format(modelName))
        for day in range(historyDays):
            print("\t--- loading day {}".format(day+1))
            for hour in range(24):
                qualityTime = (datetime.datetime.utcnow() + datetime.timedelta(hours=(-(24*day + hour + 1)))).strftime("%Y-%m-%dT%H:%M:%SZ")
                quality = random.uniform(0.75,0.95)
                qualityMetric = {
                    "metric_type": "quality",
                    "binding_id": bindingGuid,
                    "timestamp": qualityTime,
                    "subscription_id": modelGuid,
                    "asset_revision": modelGuid,
                    "value": {
                        "quality": quality,
                        "threshold": 0.8,
                        "metrics": [
                            {
                                "name": "auroc",
                                "value": quality,
                                "threshold": 0.8
                            }
                        ]
                    }
                }
                response = requests.post(metricsurl, json=[qualityMetric], headers=iamHeaders)

        numscores = 100
        print("\tGenerate {} new scoring requests to AIOS: {}".format(numscores, modelName))
        if modelName == env['heart_drug_model_info']['model_name']:
            for i in range(numscores):
                scoreInput = {"fields": ["AGE", "SEX", "BP", "CHOLESTEROL","NA","K"],
                    "values": [[random.randint(15,80),
                        random.choice(["F", "M"]),
                        random.choice(["HIGH", "LOW", "NORMAL"]),
                        random.choice(["HIGH", "NORMAL"]),
                        random.uniform(0.5, 0.9),
                        random.uniform(0.02, 0.08)]]}
                scoreOutput = wmlClient.deployments.score(deploymentUrl, scoreInput)
        else:
            print("\t--- Sample scoring not yet supported for model: {}".format(modelName))

        print("\tTrigger immediate fairness check AIOS: {}".format(modelName))
        subscription.fairness_monitoring.run()
        print("\tTrigger immediate quality check AIOS: {}".format(modelName))
        subscription.quality_monitoring.run()

    def version(self):
        return "1.0.0"

    def verifyVersionOfLib(self, libName,minVersionTuple,howToUpgrade):
        result = executeCommandWithResult('pip show {}'.format(libName))
        for line in result.splitlines():
            if line.split()[0].strip() == 'Version:':
                version = line.split()[1].strip().split('.')
                for idx, elem in enumerate(version):
                    if  int(elem.strip('()')) < minVersionTuple[idx]:
                        print("Library {} must have version {}".format(libName, minVersionTuple))
                        print("Please do '{}'".format(howToUpgrade))
                        exit(5)

### MAIN

if __name__ == '__main__':

    tool = AIOSTool
    print("\nAI OpenScale sample setup tool version {}:".format(tool.version(tool)))

    # verify required libs
    tool.verifyVersionOfLib(tool, 'ibm-ai-openscale', [1,0,89], "pip install -I --user --index https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple ibm-ai-openscale")
    tool.verifyVersionOfLib(tool, 'watson-machine-learning-client', [1,0,339],"pip install -I --user --index https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple watson-machine-learning-client")

    # initialize
    args = tool.processArgs(tool)
    environment = Environments(args).getEnvironment()
    historyDays = int(args.history)

    # create the needed service instances and WML model deployment
    ibmCloudServices = None
    initialize(args, environment)
    if args.bx:
        ibmCloudServices = SetupIBMCloudServicesBx(args, environment)
    else:
        ibmCloudServices = SetupIBMCloudServicesRest(args, environment)

    aiosCredentials = ibmCloudServices.setupAIOS()
    wmlCredentials = ibmCloudServices.setupWML()
    postgresCredentials = ibmCloudServices.setupPostgresDatabase()

    (modelGuid, modelName, deployGuid, deployName, modelMetaData) = tool.setupWMLModels(tool, wmlCredentials, environment)
    print("Model Name: {}  Model GUID: {}".format(modelName, modelGuid))
    print("Deployment Name: {}  Deployment GUID: {}".format(deployName, deployGuid))
    datamartName = args.datamartName
    if datamartName == 'aiosfastpath':
        datamartName = environment['datamart_name']

    # Configure the datamart
    aiosPythonClient = tool.getAIOSPythonClient(tool, aiosCredentials)
    tool.createDatamart(tool, datamartName, aiosPythonClient, postgresCredentials)
    wmlBindingGuid = tool.bindWMLToAIOS(tool, aiosPythonClient, wmlCredentials)
    modelSubscription = tool.registerModelToAIOS(tool, modelName, modelGuid, wmlBindingGuid, aiosPythonClient, modelMetaData, datamartName, aiosCredentials, environment)
    tool.generateSampleScoring(tool, datamartName, aiosCredentials, modelName, modelGuid, deployGuid, wmlBindingGuid, modelSubscription, aiosPythonClient, environment, historyDays)

    print('\nDone. The AI OpenScale dashboard can be accessed at: {}/aiopenscale'.format(environment['aios_url']))
