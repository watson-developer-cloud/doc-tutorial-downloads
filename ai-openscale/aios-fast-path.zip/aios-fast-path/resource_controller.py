# ----------------------------------------------------------------------------------------------------
# IBM Confidential
# OCO Source Materials
# 5900-A3Q, 5737-J33
# Copyright IBM Corp. 2018
# The source code for this program is not published or other-wise divested of its trade
# secrets, irrespective of what has been deposited with the U.S.Copyright Office.
# ----------------------------------------------------------------------------------------------------
from utils import *
import json as json_import
import time
import logging
import requests

DEFAULT_RESOURCE_GROUP_URL = 'https://resource-manager.bluemix.net/v2'
DEFAULT_URL = 'https://resource-controller.bluemix.net'
ROLE_WRITER = 'Writer'
REGION_ID = 'us-south'

RESOURCE_ID_AIOPENSCALE = '2ad019f3-0fd6-4c25-966d-f3952481a870'
RESOURCE_ID_MACHINE_LEARNING = '51c53b72-918f-4869-b834-2d99eb28422a'
RESOURCE_ID_OBJECT_STORAGE = 'dff97f5c-bc5e-4455-b470-411c3edbe49c'

PLAN_ID_AIOPENSCALE = '967ba182-c6e0-4adc-92ef-661a822cc1d7'
PLAN_ID_MACHINE_LEARNING = '3f6acf43-ede8-413a-ac69-f8af3bb0cbfe'
PLAN_ID_OBJECT_STORAGE = '2fdf0c08-2d32-4f46-84b5-32e0c92fffd8'


class ResourceController(object):
    def __init__(self, access_token, url=DEFAULT_URL):
        self.url = url
        self.access_token = access_token

    def _request(self, method, url, headers={}, params=None, data=None, json=None, accept_json=True, **kwargs):
        full_url = self.url + url if url.startswith('/') else url

        headers.update({
            'Authorization': 'Bearer {0}'.format(self.access_token)
        })
        if accept_json:
            headers['accept'] = 'application/json'

        if not data and json is not None:
            data = json_import.dumps(json)
            headers.update({'content-type': 'application/json'})

        response = requests.request(method=method, url=full_url,
                                    headers=headers, params=params,
                                    data=data, **kwargs)

        if 200 <= response.status_code <= 299:
            return response.json() if accept_json else response.text
        else:
            raise Exception(response.text)

    def list_resource_group(self, account_id=None):
        params = {'account_id': account_id} if account_id else {}
        response = self._request(
            method='GET',
            url=DEFAULT_RESOURCE_GROUP_URL + '/resource_groups',
            params=params)

        return response['resources']

    def get_default_resource_group(self, account_id=None):
        resource_groups = self.list_resource_group(account_id=account_id)
        resource_groups = [r['id'] for r in resource_groups if r['default']]
        return resource_groups[0] if len(resource_groups) > 0 else None

    def get_resource_group_by_name(self, name):
        resource_groups = self.list_resource_group()
        resource_groups = [r['id'] for r in resource_groups if r['name'] == name]
        return resource_groups[0] if len(resource_groups) > 0 else None

    def create_instance(self, name, target, resource_group, resource_plan_id):
        data = {
            'name': name,
            'target': target,
            'resource_group': resource_group,
            'resource_plan_id': resource_plan_id,
            'tags': ['self-created']
        }
        response = self._request(
            method='POST',
            url='/v2/resource_instances',
            json=data)

        return response

    def list_instances(self, resource_id=None):
        params = {'resource_id': resource_id} if resource_id else {}
        response = self._request(
            method='GET',
            url='/v2/resource_instances',
            params=params)

        return response

    def delete_instance(self, guid, recursive=True):
        response = self._request(
            method='DELETE',
            accept_json=False,
            params={'recursive': recursive},
            url='/v2/resource_instances/{0}'.format(guid))

        return response

    def create_instance_key(self, source, role):
        data = {
            'name': 'aios-credentials',
            'source': source,
            'role': role
        }
        response = self._request(
            method='POST',
            url='/v2/resource_keys',
            json=data)

        return response

    def list_instance_keys(self, guid):
        response = self._request(
            method='GET',
            url='/v2/resource_instances/{0}/resource_keys'.format(guid))

        return response

    def delete_instance_key(self, guid):
        response = self._request(
            method='DELETE',
            url='/v2/resource_keys/{0}'.format(guid),
            accept_json=False)

        return response

    def get_or_create_instance(self, resource_id, resource_name=None, resource_plan_id=None, resource_group=None, resource_group_name=None, create_credentials=True, target='us-south'):
        """Returns a service instance.
        If there is no instance available, a new one is provisioned.
        If there is no existing service key, a new one is created.

        Arguments:
            resource_id {string} -- The resource_id that identifies the service in the global catalog
            resource_plan_id {string} -- resource plan id. spark and compose-for-postgres plans are constants in this module
            resource_group {string} -- resource group id.
            resource_group_name {string} -- resource group name.
            create_credentials {boolean} -- If True, credentials will be created if they don't exist
        Returns:
            dict -- The service instance with valid credentials, dictionary with: id, name, created_at and credentials
        """
        '''
        Returns an existing service instance.
        If there is no instance available, a new one is provisioned.
        If there is no existing service key, a new one is created.
        '''
        instances = self.list_instances(resource_id=resource_id)
        instance = instances['resources'][0] if instances['resources'] else None

        if not instance:
            if resource_group_name:
                resource_group = self.get_resource_group_by_name(resource_group_name)
            if not resource_group:
                resource_group = self.get_default_resource_group()

            name = resource_name if resource_name else 'aios-{0}-{1}'.format(resource_id, time.time())
            instance = self.create_instance(
                name=name,
                target=target,
                resource_group=resource_group,
                resource_plan_id=resource_plan_id)

        if create_credentials:
            keys = self.list_instance_keys(instance['guid'])
            key = keys['resources'][0] if keys['resources'] else None

            if not key:
                key = self.create_instance_key(
                    source=instance['guid'],
                    role=ROLE_WRITER
                )
            instance['credentials'] = key['credentials']
        else:
            instance['credentials'] = None

        return {
            'id': instance['guid'],
            'crn': instance['id'],
            'name': instance['name'],
            'created_at': instance['created_at'],
            'credentials': instance['credentials']
        }

    def __str__(self):
        return 'ResourceController: url: {1}, access_token: {0}'.format(url, access_token[:5])
