# aios-fast-path

This repository is trying to create a fast path toolkit to setup AI OpenScale.

This tool allows user to get started real quick by exploring the environment to understand what user has, and then provision corresponding services needed to run AI OpenScale, then setup the models and setup monitoring conditions.

### Prerequisites:
https://github.ibm.com/aiopenscale/aios-fast-path/blob/master/requirements.md

### Usage:
```
usage: setupAIOS.py [-h] -a APIKEY [--resourceGroup RESOURCEGROUP]
                    [--postgresVCAP POSTGRESVCAP] [--wmlVCAP WMLVCAP]
                    [--datamartName DATAMARTNAME] [--env ENV]
                    [--history HISTORY] [--bx]

required arguments:
  -a APIKEY, --apiKey APIKEY
                        IBM Cloud APIKey

optional arguments:
  -h, --help            show this help message and exit
  --resourceGroup RESOURCEGROUP
                        Resource Group to use. If not specified, then
                        "default" group is used
  --postgresVCAP POSTGRESVCAP
                        Path to postgres properties file. If not specified,
                        then the internal AIOS database is used
  --wmlVCAP WMLVCAP     Path to WML properties file
  --datamartName DATAMARTNAME
                        Specify data mart name, default is "aiosfastpath"
  --env ENV             Environment to use: ypprod, ypqa, ys1dev or
                        icp:https://0.0.0.0:0000. Default is "ypprod"
  --history HISTORY     Days of history to preload. Default is 7
  --bx                  Specify (without a value) to use IBM Cloud CLI (bx
                        CLI), default uses Rest API.
```

### Example:
```
#!/bin/bash

APIKEY=<PLATFORM_API_KEY>

bx login -a https://api.ng.bluemix.net --apikey $APIKEY -o yongli2@us.ibm.com -s dev
bx resource service-key-delete 'aiopenscale-fastpath-instance-credentials' -f
bx resource service-instance-delete 'aiopenscale-fastpath-instance' -f

python3 setupAIOS.py --apiKey $APIKEY
```
The first few commands perform cleanup so that we can run this script multiple times. These steps are optional and need the IBM Cloud CLI to be installed, and alternatively can be manually deleted via the IBM Cloud Dashboard (https://console.bluemix.net/dashboard/apps).

This work is tracked: https://github.ibm.com/aiopenscale/tracker/issues/2634
